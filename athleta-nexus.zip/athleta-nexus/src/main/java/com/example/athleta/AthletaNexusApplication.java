package com.example.athleta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AthletaNexusApplication {

    public static void main(String[] args) {
        SpringApplication.run(AthletaNexusApplication.class, args);
    }
}