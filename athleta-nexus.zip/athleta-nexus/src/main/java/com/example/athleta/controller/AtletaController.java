package com.example.athleta.controller;

import com.example.athleta.model.Atleta;
import com.example.athleta.model.Clube;
import com.example.athleta.repository.AtletaRepository;
import com.example.athleta.repository.ClubeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/atletas")
public class AtletaController {

    @Autowired
    private AtletaRepository atletaRepository;

    @Autowired
    private ClubeRepository clubeRepository;

    @PostMapping
    public Atleta inserirAtleta(@RequestBody Atleta atleta) {
        if (atleta.getClube() != null && atleta.getClube().getId() != null) {
            Optional<Clube> clubeOpt = clubeRepository.findById(atleta.getClube().getId());
            clubeOpt.ifPresent(atleta::setClube);
        }
        return atletaRepository.save(atleta);
    }

    @DeleteMapping("/{id}")
    public void removerAtleta(@PathVariable Long id) {
        atletaRepository.deleteById(id);
    }

    @GetMapping
    public List<Atleta> listarTodosAtletas() {
        return atletaRepository.findAll();
    }

    @GetMapping("/{id}")
    public Optional<Atleta> buscarAtletaPorId(@PathVariable Long id) {
        return atletaRepository.findById(id);
    }

    @GetMapping("/nome/{nome}")
    public List<Atleta> buscarAtletasPorNome(@PathVariable String nome) {
        return atletaRepository.findByNomeCompletoContaining(nome);
    }

    @GetMapping("/idadeMaiorQue/{idade}")
    public List<Atleta> buscarAtletasIdadeMaiorQue(@PathVariable Integer idade) {
        return atletaRepository.findByIdadeGreaterThan(idade);
    }

    @GetMapping("/nomeComecaCom/{nome}")
    public List<Atleta> buscarAtletasNomeComecaCom(@PathVariable String nome) {
        return atletaRepository.findByNomeCompletoStartingWith(nome);
    }

    @GetMapping("/top3MaisVelhos")
    public List<Atleta> buscarTop3MaisVelhos() {

        return atletaRepository.findTop3ByOrderByIdadeDesc();
    }

    @GetMapping("/porClube/{clubeId}")
    public List<Atleta> buscarAtletasPorClubeId(@PathVariable Long clubeId) {
        return atletaRepository.findByClubeId(clubeId);
    }

    @GetMapping("/porNomeClube/{nomeClube}")
    public List<Atleta> buscarAtletasPorNomeClube(@PathVariable String nomeClube) {
        return atletaRepository.findByClubeNome(nomeClube);
    }

    @GetMapping("/porClubeIdMaiorQue/{clubeId}")
    public List<Atleta> buscarAtletasPorClubeIdMaiorQue(@PathVariable Long clubeId) {
        return atletaRepository.findByClubeIdGreaterThan(clubeId);
    }

    @GetMapping("/porClubeNomeComecaCom/{nomeClube}")
    public List<Atleta> buscarAtletasPorClubeNomeComecaCom(@PathVariable String nomeClube) {
        return atletaRepository.findByClubeNomeStartingWith(nomeClube);
    }
}
