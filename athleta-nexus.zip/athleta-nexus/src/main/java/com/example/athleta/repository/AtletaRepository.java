package com.example.athleta.repository;

import com.example.athleta.model.Atleta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AtletaRepository extends JpaRepository<Atleta, Long> {

    List<Atleta> findByNomeCompletoContaining(String nome);

    List<Atleta> findByIdadeGreaterThan(Integer idade);

    List<Atleta> findByNomeCompletoStartingWith(String nome);

    List<Atleta> findTop3ByOrderByIdadeDesc();

    List<Atleta> findByClubeId(Long clubeId);

    List<Atleta> findByClubeNome(String nomeClube);

    List<Atleta> findByClubeIdGreaterThan(Long clubeId);

    List<Atleta> findByClubeNomeStartingWith(String nomeClube);
}