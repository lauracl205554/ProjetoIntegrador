package com.example.athleta.repository;

import com.example.athleta.model.Clube;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ClubeRepository extends JpaRepository<Clube, Long> {

    List<Clube> findByIdGreaterThan(Long id);

    List<Clube> findByNomeStartingWith(String nome);

    List<Clube> findByNomeContaining(String nome);

    List<Clube> findByNome(String nome);
}