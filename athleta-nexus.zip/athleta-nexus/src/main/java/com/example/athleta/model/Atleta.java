package com.example.athleta.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;

@Entity
@Table(name = "atletas")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Atleta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String nomeCompleto;

    @Column(unique = true, length = 100)
    private String email;

    @Column(length = 100)
    private String cidade;

    @Column(length = 50)
    private String modalidade;

    @Column
    private Integer idade;

    @Column(length = 50)
    private String posicao;

    @Column(length = 200)
    private String objetivosEsportivos;

    @Column
    private Double altura;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "clube_id")
    @JsonIgnoreProperties("atletas")
    private Clube clube;

    public Atleta() {
    }

    public Atleta(String nomeCompleto, String email, String cidade, String modalidade,
                  Integer idade, String posicao, String objetivosEsportivos, Double altura) {
        this.nomeCompleto = nomeCompleto;
        this.email = email;
        this.cidade = cidade;
        this.modalidade = modalidade;
        this.idade = idade;
        this.posicao = posicao;
        this.objetivosEsportivos = objetivosEsportivos;
        this.altura = altura;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNomeCompleto() {
        return nomeCompleto;
    }

    public void setNomeCompleto(String nomeCompleto) {
        this.nomeCompleto = nomeCompleto;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getModalidade() {
        return modalidade;
    }

    public void setModalidade(String modalidade) {
        this.modalidade = modalidade;
    }

    public Integer getIdade() {
        return idade;
    }

    public void setIdade(Integer idade) {
        this.idade = idade;
    }

    public String getPosicao() {
        return posicao;
    }

    public void setPosicao(String posicao) {
        this.posicao = posicao;
    }

    public String getObjetivosEsportivos() {
        return objetivosEsportivos;
    }

    public void setObjetivosEsportivos(String objetivosEsportivos) {
        this.objetivosEsportivos = objetivosEsportivos;
    }

    public Double getAltura() {
        return altura;
    }

    public void setAltura(Double altura) {
        this.altura = altura;
    }

    public Clube getClube() {
        return clube;
    }

    public void setClube(Clube clube) {
        this.clube = clube;
    }
}
