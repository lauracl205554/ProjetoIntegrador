package com.example.athleta.controller;

import com.example.athleta.model.Clube;
import com.example.athleta.repository.ClubeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/clubes")
public class ClubeController {

    @Autowired
    private ClubeRepository clubeRepository;

    @PostMapping
    public Clube inserirClube(@RequestBody Clube clube) {
        return clubeRepository.save(clube);
    }

    @DeleteMapping("/{id}")
    public void removerClube(@PathVariable Long id) {
        clubeRepository.deleteById(id);
    }

    @GetMapping
    public List<Clube> listarTodosClubes() {
        return clubeRepository.findAll();
    }

    @GetMapping("/idMaiorQue/{id}")
    public List<Clube> buscarClubesIdMaiorQue(@PathVariable Long id) {
        return clubeRepository.findByIdGreaterThan(id);
    }

    @GetMapping("/{id}")
    public Optional<Clube> buscarClubePorId(@PathVariable Long id) {
        return clubeRepository.findById(id);
    }

    @GetMapping("/nomeComecaCom/{nome}")
    public List<Clube> buscarClubesNomeComecaCom(@PathVariable String nome) {
        return clubeRepository.findByNomeStartingWith(nome);
    }

    @GetMapping("/nomeContem/{nome}")
    public List<Clube> buscarClubesNomeContem(@PathVariable String nome) {
        return clubeRepository.findByNomeContaining(nome);
    }
}
