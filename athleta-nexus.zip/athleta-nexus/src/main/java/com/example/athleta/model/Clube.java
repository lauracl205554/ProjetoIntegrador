package com.example.athleta.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "clubes")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Clube {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String nome;

    @Column(length = 100)
    private String cidade;

    @Column(unique = true, length = 100)
    private String email;

    @Column(length = 50)
    private String modalidadePrincipal;

    @OneToMany(mappedBy = "clube", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnoreProperties("clube")
    private List<Atleta> atletas;

    public Clube() {
    }

    public Clube(String nome, String cidade, String email, String modalidadePrincipal) {
        this.nome = nome;
        this.cidade = cidade;
        this.email = email;
        this.modalidadePrincipal = modalidadePrincipal;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getModalidadePrincipal() {
        return modalidadePrincipal;
    }

    public void setModalidadePrincipal(String modalidadePrincipal) {
        this.modalidadePrincipal = modalidadePrincipal;
    }

    public List<Atleta> getAtletas() {
        return atletas;
    }

    public void setAtletas(List<Atleta> atletas) {
        this.atletas = atletas;
    }
}
