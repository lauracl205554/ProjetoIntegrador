# AthletaNexus – API REST (Spring Boot)

**Projeto Integrador – LPM (Linguagem de Programação Multiplataforma)**  
Colégio Técnico de Limeira – COTIL / Unicamp  
**Professora:** Tania Basso  

**Integrantes:**  
- Eloah Saito  
- Lucas Daniel de Carvalho  
- Laura Corrêa de Oliveira  
- João Vitor de Oliveira Fernandes  

---

## 1. Descrição do Projeto

O **AthletaNexus** é uma plataforma que utiliza valências físicas, técnicas e objetivos esportivos para criar conexões precisas entre atletas e treinadores/olheiros.  

Através de perfis dinâmicos, o sistema transforma potencial invisível em realidade profissional, eliminando barreiras geográficas e burocráticas para atletas amadores (especialmente de futebol e basquete).

Este repositório contém a **API REST** desenvolvida em Java com o framework Spring Boot, atendendo aos requisitos funcionais e à atividade de relacionamento **1:N** solicitada em aula.

---

## 2. Relacionamento 1:N implementado

| Lado | Entidade | Cardinalidade |
|------|----------|---------------|
| **1** | Clube    | Um clube      |
| **N** | Atleta   | Muitos atletas |

- Um **Clube** pode ter vários **Atletas**.
- Cada **Atleta** pertence a no máximo um **Clube**.

---

## 3. Tecnologias utilizadas

- Java 17
- Spring Boot 4.1.1
- Spring Web
- Spring Data JPA + Hibernate
- MySQL
- Maven
- Postman (para testes)


A API ficará disponível em: **http://localhost:8080**

---

## 4. Endpoints da API

### 4.1 Clube (Lado 1)

| Método HTTP | Endpoint                              | Descrição                                      |
|-------------|---------------------------------------|------------------------------------------------|
| POST        | `/api/clubes`                         | Inserir clube                                  |
| DELETE      | `/api/clubes/{id}`                    | Remover clube por id                           |
| GET         | `/api/clubes`                         | Listar todos os clubes                         |
| GET         | `/api/clubes/{id}`                    | Buscar clube por id                            |
| GET         | `/api/clubes/idMaiorQue/{id}`         | Clubes com id **maior que** o valor informado  |
| GET         | `/api/clubes/nomeComecaCom/{nome}`    | Clubes cujo nome **começa com**                |
| GET         | `/api/clubes/nomeContem/{nome}`       | Clubes cujo nome **contém** (qualquer posição) |

### 4.2 Atleta (Lado N)

| Método HTTP | Endpoint                              | Descrição                                      |
|-------------|---------------------------------------|------------------------------------------------|
| POST        | `/api/atletas`                        | Inserir atleta                                 |
| DELETE      | `/api/atletas/{id}`                   | Remover atleta por id                          |
| GET         | `/api/atletas`                        | Listar todos os atletas                        |
| GET         | `/api/atletas/{id}`                   | Buscar atleta por id                           |
| GET         | `/api/atletas/nome/{nome}`            | Atletas cujo nome **contém**                   |
| GET         | `/api/atletas/idadeMaiorQue/{idade}`  | Atletas com idade **maior que**                |
| GET         | `/api/atletas/nomeComecaCom/{nome}`   | Atletas cujo nome **começa com**               |
| GET         | `/api/atletas/top3MaisVelhos`         | Os **3 atletas mais velhos**                   |

### 4.3 Relacionamentos (N relacionados ao lado 1)

| Método HTTP | Endpoint                                      | Descrição                                              |
|-------------|-----------------------------------------------|--------------------------------------------------------|
| GET         | `/api/atletas/porClube/{clubeId}`             | Atletas de um clube (por **id** do clube)              |
| GET         | `/api/atletas/porNomeClube/{nomeClube}`       | Atletas de um clube (por **nome** do clube)            |
| GET         | `/api/atletas/porClubeIdMaiorQue/{clubeId}`   | Atletas de clubes com **id maior que**                 |
| GET         | `/api/atletas/porClubeNomeComecaCom/{nome}`   | Atletas de clubes cujo nome **começa com**             |

---

## 5. Exemplos de JSON para o Postman

### Inserir Clube
```http
POST http://localhost:8080/api/clubes
Content-Type: application/json

{
  "nome": "Santos FC Sub-17",
  "cidade": "Santos - SP",
  "email": "base@santosfc.com.br",
  "modalidadePrincipal": "Futebol"
}
```

### Inserir Atleta (vinculado a um clube)
```http
POST http://localhost:8080/api/atletas
Content-Type: application/json

{
  "nomeCompleto": "Lucas Moreira",
  "email": "lucas.moreira@email.com",
  "cidade": "São Paulo - SP",
  "modalidade": "Futebol",
  "idade": 17,
  "posicao": "Atacante",
  "objetivosEsportivos": "Jogar em clube profissional e ser convocado para a seleção sub-20",
  "altura": 1.78,
  "clube": {
    "id": 1
  }
}
```

### Exemplos de consultas
```
GET http://localhost:8080/api/atletas/idadeMaiorQue/16
GET http://localhost:8080/api/atletas/top3MaisVelhos
GET http://localhost:8080/api/atletas/porClube/1
GET http://localhost:8080/api/atletas/porNomeClube/Santos FC Sub-17
GET http://localhost:8080/api/clubes/nomeComecaCom/San
```

---



## 7. Observações importantes

- Utilizado `@OneToMany` e `@ManyToOne` para o relacionamento 1:N.
- Queries personalizadas feitas com `@Query` (JPQL e SQL nativo), conforme ensinado em aula.
- `@JsonIgnoreProperties` foi usado para evitar loop infinito na serialização JSON.
- O projeto atende aos **Requisitos Funcionais** de Gestão de Perfil do Atleta e Busca/Filtro para Recrutadores.
- Foco inicial nas modalidades **Futebol** e **Basquete**, com arquitetura preparada para expansão.

---

**Data de entrega prevista:** Outubro/2027 (conforme Termo de Abertura)  
**Versão da API:** 1.0
